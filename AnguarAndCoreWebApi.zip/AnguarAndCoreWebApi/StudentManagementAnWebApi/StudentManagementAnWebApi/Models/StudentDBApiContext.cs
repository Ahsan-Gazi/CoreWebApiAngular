﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagementAnWebApi.Models
{
    public class StudentDBApiContext:IdentityDbContext
    {
        public StudentDBApiContext(DbContextOptions<StudentDBApiContext>options):base(options)
        {

        }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Student> Students { get; set; }

        public DbSet<ApplicationUser> ApplicationUsers { get; set; }
    }
}
