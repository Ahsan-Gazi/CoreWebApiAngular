﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace StudentManagementAnWebApi.Models
{
    public class Student
    {
        [Key]
        public int StudentId { get; set; }
        [Column(TypeName ="Varchar(20)")]
        [Required]
        public string StudentName { get; set; }
        [Column(TypeName = "Varchar(50)")]
        [Required]
        public string Email { get; set; }
        [Column(TypeName = "Varchar(10)")]
        [Required]
        public string Gender { get; set; }
        public int DepartmentId { get; set; }

    }
}
