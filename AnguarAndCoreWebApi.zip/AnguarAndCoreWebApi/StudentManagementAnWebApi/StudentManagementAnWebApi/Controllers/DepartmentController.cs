﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagementAnWebApi.Models;

namespace StudentManagementAnWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class DepartmentController : ControllerBase
    {
        private readonly StudentDBApiContext _dContext;

        public DepartmentController(StudentDBApiContext dContext)
        {
            _dContext = dContext;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Department>>> GetDepartments()
        {
            return await _dContext.Departments.ToListAsync();
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Department>> GetDepartment(int id)
        {
            var department = await _dContext.Departments.FindAsync(id);
            if (department==null)
            {
                return NotFound();
            }
            return department;
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDepartment(int id,Department department)
        {
            if (id!=department.DepartmentId)
            {
                return BadRequest();
            }
            _dContext.Entry(department).State = EntityState.Modified;
            try
            {
                await _dContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DepartmentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
                
            }
            return NoContent();
        }
        [HttpPost]
        public async Task<ActionResult<Department>>PostDepartment(Department department)
        {
            _dContext.Departments.Add(department);
            await _dContext.SaveChangesAsync();
            return CreatedAtAction("GetDepartment", new { id = department.DepartmentId }, department);
        }
        [HttpDelete("{id}")] 
        public async Task<ActionResult<Department>> DeleteBank(int id)
        {
            var department = await _dContext.Departments.FindAsync(id);
            if (department==null)
            {
                return NotFound();
            }
            _dContext.Departments.Remove(department);
            await _dContext.SaveChangesAsync();
            return department;
        }

        private bool DepartmentExists(int id)
        {
            return _dContext.Departments.Any(d => d.DepartmentId == id);
        }
    }
}