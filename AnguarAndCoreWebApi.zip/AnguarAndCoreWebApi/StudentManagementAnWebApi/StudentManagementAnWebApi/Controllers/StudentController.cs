﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagementAnWebApi.Models;

namespace StudentManagementAnWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class StudentController : ControllerBase
    {
        private readonly StudentDBApiContext _stCondet;

        public StudentController(StudentDBApiContext stCondet)
        {
            _stCondet = stCondet;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Student>>> GetStudents()
        {
            return await _stCondet.Students.ToListAsync();
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Student>> GetStudent(int id)
        {
            var student = await _stCondet.Students.FindAsync(id);
            if (student==null)
            {
                return NotFound();
            }
            return student;
        }
        public async Task<IActionResult> PutStudent(int id,Student student)
        {
            if (id!=student.StudentId)
            {
                return BadRequest();
            }
            _stCondet.Entry(student).State = EntityState.Modified;
            try
            {
                await _stCondet.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }
        [HttpPost]
        public async Task<ActionResult<Student>> PostStudent(Student student)
        {
            _stCondet.Students.Add(student);
            await _stCondet.SaveChangesAsync();
            return CreatedAtAction("GetStudent", new { id = student.StudentId }, student);
        }
        [HttpDelete("{id}")]
        public async Task<ActionResult<Student>> DeleteStudent(int id)
        {
            var student = await _stCondet.Students.FindAsync(id);
            if (student==null)
            {
                return NotFound();
            }
            _stCondet.Students.Remove(student);
            await _stCondet.SaveChangesAsync();
            return student;
        }
        private bool StudentExists(int id)
        {
            return _stCondet.Students.Any(st => st.StudentId == id);
        }
    }
}