
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';

import{StudentService} from './../shared/student.service';
import{DepartmentService} from './../shared/department.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  studentForms:FormArray=this.fb.array([]);
  departmentList=[];
  notification=null;

  constructor(private router: Router, private fb:FormBuilder,
    private departmentService:DepartmentService,
    private service:StudentService) { }

  ngOnInit(){
    this.departmentService.getDepartmentList()
    .subscribe(res=>this.departmentList=res as []);

    

    this.service.getStudentList().subscribe(
      res=>{
        if (res==[])
        this.addStudentForm();
        else{
          //generate formaray as per the data received from Student table
          (res as[]).forEach((student:any)=>{
            this.studentForms.push(this.fb.group({
              studentId:[student.studentId],
              studentName:[student.studentName,Validators.required],
              email:[student.email,Validators.required],
              departmentId:[student.departmentId,Validators.min(1)],
              gender:[student.gender,Validators.required]
            }));
          });
        }

      }
    );
   
    
    
  }
addStudentForm(){
  this.studentForms.push(this.fb.group({
    studentId:[0],
    studentName:['',Validators.required],
    email:['',Validators.required],
    departmentId:[0,Validators.min(1)],
    gender:['',Validators.required]
  }));
}
recordSubmit(fg:FormGroup){
  if(fg.value.studentId==0)
  this.service.postStudent(fg.value).subscribe(
    (res:any)=>{
      fg.patchValue({studentId: res.studentId});
      this.showNotification('insert');
    }
  );
else 
this.service.putStudent(fg.value).subscribe(
  (res:any)=>{
    this.showNotification('update');
    
  }
);
}
onDelete(studentId,i){
  if(studentId==0)
  this.studentForms.removeAt(i);
  else if(confirm('Are you sure to delete this record?'))
  this.service.deleteStudent(studentId).subscribe(
res=>{
  this.studentForms.removeAt(i);
  this.showNotification('delete');
}
  );
}
showNotification(systStudent){
switch (systStudent) {
  case 'insert':
    this.notification={class:'text-success',message:'saved!'};
    
    break;
    case 'update':
    this.notification={class:'text-primary',message:'updated!'};
break;
case 'delete':
    this.notification={class:'text-danger',message:'deleted!'};
    break;
  default:
    break;
}
setTimeout(()=>{
this.notification=null;
},3000);
}
onLogout() {
  localStorage.removeItem('token');
  this.router.navigate(['/user/login']);
}
}
