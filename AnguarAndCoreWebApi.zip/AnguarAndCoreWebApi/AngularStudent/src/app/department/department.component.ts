import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import{DepartmentService} from './../shared/department.service';
import{FormBuilder,FormArray,Validators,FormGroup} from '@angular/forms';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {
departmentForms: FormArray=this.fb.array([])
notification=null;
  constructor(private fb:FormBuilder,
    private departmentService:DepartmentService) { }

  ngOnInit() {
    this.departmentService.getDepartmentList().subscribe(
      res=>{
        if(res==[])
        this.addDepartmentForm();
        else{
          (res as[]).forEach((department:any)=>{
            this.departmentForms.push(this.fb.group({
              departmentId:[department.departmentId],
              departmentName:[department.departmentName,Validators.required]
            }));
          });
        }
      }
    );
    
  }
  
  addDepartmentForm(){
    this.departmentForms.push(this.fb.group({
      departmentId:[0],
      departmentName:['',Validators.required]
    }));
  }
  recordSubmit(fg:FormGroup){
    if(fg.value.departmentId==0)
    this.departmentService.postDepartment(fg.value).subscribe(
      (res:any)=>{
        fg.patchValue({departmentId:res.departmentId});
        this.showNotification('insert');
      }
    );
    else
    this.departmentService.putDepartment(fg.value).subscribe(
      (res:any)=>{
        this.showNotification('update');
      }
    );
  }
  onDelete(departmentId,i){
    if(departmentId==0)
    this.departmentForms.removeAt(i);
    else if(confirm('Are you sure to delete this record?'))
    this.departmentService.deleteDepartment(departmentId).subscribe(
      res=>{
        this.departmentForms.removeAt(i);
        this.showNotification('delete');
      }
    );
    
  }
  showNotification(catDepartment){
    switch (catDepartment) {
      case 'insert':
        this.notification={class:'text-success',message:'saved'};
        break;
        case 'update':
          this.notification={class:'text-primary',message:'updated'};
          break;
          case 'delete':
            this.notification={class:'text-danger',message:'deleted'};
            break;
    
      default:
        break;
    }
    setTimeout(()=>{
      this.notification=null;
    },3000);
  }
}
