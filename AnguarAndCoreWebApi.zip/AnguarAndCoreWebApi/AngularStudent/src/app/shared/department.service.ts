import { Injectable } from '@angular/core';

import {HttpClient} from "@angular/common/http";
import{environment} from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  constructor( private http:HttpClient) { }

  postDepartment(formData){
    return this.http.post(environment.apiBaseURI+'/Department',formData);
  }
putDepartment(formData){
  return this.http.put(environment.apiBaseURI+'/Department/'+formData.departmentId,formData);
}
deleteDepartment(id){
  return this.http.delete(environment.apiBaseURI+'/Department/'+id);
}

    getDepartmentList(){

    return this.http.get(environment.apiBaseURI +'/Department');
  }
}
